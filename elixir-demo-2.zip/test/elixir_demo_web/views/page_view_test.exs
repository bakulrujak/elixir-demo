defmodule ElixirDemoWeb.PageViewTest do
  use ElixirDemoWeb.ConnCase, async: true
end
