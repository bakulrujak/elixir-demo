defmodule ElixirDemoWeb.LayoutViewTest do
  use ElixirDemoWeb.ConnCase, async: true
end
