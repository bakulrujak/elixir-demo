defmodule ElixirDemoWeb.LayoutView do
  use ElixirDemoWeb, :view
end
